import warnings
warnings.filterwarnings("ignore", message=".*unpickle estimator.*")
try:
    from sklearn.exceptions import InconsistentVersionWarning
    warnings.filterwarnings("ignore", category=InconsistentVersionWarning)
except ImportError:
    pass

import numpy as np
import pandas as pd

CATEGORICAL_CATEGORIES = {
    'gender': ['Female', 'Male'],
    'Partner': ['No', 'Yes'],
    'Dependents': ['No', 'Yes'],
    'PhoneService': ['No', 'Yes'],
    'MultipleLines': ['No', 'No phone service', 'Yes'],
    'InternetService': ['DSL', 'Fiber optic', 'No'],
    'OnlineSecurity': ['No', 'No internet service', 'Yes'],
    'OnlineBackup': ['No', 'No internet service', 'Yes'],
    'DeviceProtection': ['No', 'No internet service', 'Yes'],
    'TechSupport': ['No', 'No internet service', 'Yes'],
    'StreamingTV': ['No', 'No internet service', 'Yes'],
    'StreamingMovies': ['No', 'No internet service', 'Yes'],
    'Contract': ['Month-to-month', 'One year', 'Two year'],
    'PaperlessBilling': ['No', 'Yes'],
    'PaymentMethod': ['Bank transfer (automatic)', 'Credit card (automatic)', 'Electronic check', 'Mailed check']
}

class ConnectTelChurnPipeline:
    """
    ConnectTel End-to-End Production Inference Pipeline
    Encapsulates preprocessing, feature alignment, standard scaling, and probability risk scoring.
    Supports single-row, batch, and streaming inference payloads with deterministic dummy encoding.
    """
    def __init__(self, scaler, model, feature_names, num_cols, business_threshold=0.28):
        self.scaler = scaler
        self.model = model
        self.feature_names = feature_names
        self.num_cols = num_cols
        self.business_threshold = business_threshold
        self.service_cols = [
            'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 
            'TechSupport', 'StreamingTV', 'StreamingMovies'
        ]
        self.cat_categories = CATEGORICAL_CATEGORIES
        
        # Pre-compute feature mapping once for sub-millisecond inference
        cat_prefixes = [
            'MultipleLines_', 'InternetService_', 'OnlineSecurity_', 'OnlineBackup_',
            'DeviceProtection_', 'TechSupport_', 'StreamingTV_', 'StreamingMovies_',
            'Contract_', 'PaymentMethod_', 'gender_', 'Partner_', 'Dependents_',
            'PhoneService_', 'PaperlessBilling_'
        ]
        self.feat_mapping = {}
        for feat in self.feature_names:
            for prefix in cat_prefixes:
                if feat.startswith(prefix):
                    self.feat_mapping[feat] = (prefix[:-1], feat[len(prefix):])
                    break

    def preprocess(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        df_clean = raw_df.copy()
        if 'customerID' in df_clean.columns:
            df_clean = df_clean.drop(columns=['customerID'])
        if 'Churn' in df_clean.columns:
            df_clean = df_clean.drop(columns=['Churn'])
            
        if 'TotalCharges' in df_clean.columns:
            df_clean['TotalCharges'] = pd.to_numeric(
                df_clean['TotalCharges'].replace(' ', np.nan), errors='coerce'
            ).fillna(0.0)
        else:
            df_clean['TotalCharges'] = 0.0

        if 'tenure' in df_clean.columns and 'MonthlyCharges' in df_clean.columns:
            df_clean['TotalChargesPerTenure'] = np.where(
                df_clean['tenure'] > 0, 
                df_clean['TotalCharges'] / df_clean['tenure'], 
                df_clean['MonthlyCharges']
            )
        else:
            df_clean['TotalChargesPerTenure'] = df_clean.get('TotalCharges', 0.0)
            
        present_service_cols = [c for c in self.service_cols if c in df_clean.columns]
        if present_service_cols:
            df_clean['ServiceCount'] = (df_clean[present_service_cols] == 'Yes').sum(axis=1)
        else:
            df_clean['ServiceCount'] = 0

        # Vectorized construction in sub-2ms
        n = len(df_clean)
        res_dict = {f: np.zeros(n, dtype=np.float32) for f in self.feature_names}
        
        for col in self.num_cols + ['SeniorCitizen']:
            if col in df_clean.columns:
                res_dict[col] = df_clean[col].to_numpy(dtype=np.float32)
                
        feat_map = getattr(self, 'feat_mapping', None)
        if not feat_map:
            cat_prefixes = [
                'MultipleLines_', 'InternetService_', 'OnlineSecurity_', 'OnlineBackup_',
                'DeviceProtection_', 'TechSupport_', 'StreamingTV_', 'StreamingMovies_',
                'Contract_', 'PaymentMethod_', 'gender_', 'Partner_', 'Dependents_',
                'PhoneService_', 'PaperlessBilling_'
            ]
            feat_map = {}
            for feat in self.feature_names:
                for prefix in cat_prefixes:
                    if feat.startswith(prefix):
                        feat_map[feat] = (prefix[:-1], feat[len(prefix):])
                        break
                        
        for feat, (col, val) in feat_map.items():
            if col in df_clean.columns:
                res_dict[feat] = (df_clean[col].to_numpy() == val).astype(np.float32)
                
        df_aligned = pd.DataFrame(res_dict, index=df_clean.index)
        df_aligned[self.num_cols] = self.scaler.transform(df_aligned[self.num_cols])
        return df_aligned

    def predict_risk(self, raw_df: pd.DataFrame) -> list:
        X_ready = self.preprocess(raw_df)
        probs = self.model.predict_proba(X_ready)[:, 1]
        
        results = []
        for i, p in enumerate(probs):
            if p >= 0.60:
                tier = "CRITICAL RISK"
                action = "Immediate VIP callback + 1-Year contract $15/mo discount"
            elif p >= self.business_threshold:
                tier = "MODERATE RISK"
                action = "Automated email loyalty bundle + Tech Support credit"
            else:
                tier = "LOW RISK"
                action = "Standard retention engagement / Autopay promotion"
                
            results.append({
                "customer_index": i,
                "churn_probability": round(float(p), 4),
                "predicted_churn": bool(p >= self.business_threshold),
                "risk_tier": tier,
                "recommended_retention_action": action
            })
        return results
