"""
ConnectTel Telecommunications - Production Quality Assurance & Verification Suite
Tests pipeline persistence, deterministic behavior, inference latency, and API endpoints.
Compatible with direct execution, pytest, and python -m unittest.
"""

import warnings
warnings.filterwarnings("ignore", message=".*unpickle estimator.*")
try:
    from sklearn.exceptions import InconsistentVersionWarning
    warnings.filterwarnings("ignore", category=InconsistentVersionWarning)
except ImportError:
    pass

import os
import sys
import time
import json
import joblib
import pandas as pd
import unittest

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROD_DIR = CURRENT_DIR if os.path.exists(os.path.join(CURRENT_DIR, "churn_pipeline.joblib")) else os.path.join(CURRENT_DIR, "production")

if PROD_DIR not in sys.path:
    sys.path.insert(0, PROD_DIR)
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

PIPELINE_PATH = os.path.join(PROD_DIR, "churn_pipeline.joblib")
SAMPLE_PATH = os.path.join(PROD_DIR, "sample_customers.json")

def test_artifacts_exist():
    """Test 1: Verify all required production artifacts exist on disk."""
    print("Test 1: Verifying production artifacts on disk...")
    required_files = [
        "churn_pipeline.joblib",
        "scaler.joblib",
        "xgb_model.json",
        "features.json",
        "sample_customers.json",
        "predict.py",
        "app.py"
    ]
    for fname in required_files:
        fpath = os.path.join(PROD_DIR, fname)
        assert os.path.exists(fpath), f"Missing artifact: {fname}"
    print("[PASS] All 7 production artifacts verified successfully.\n")

def test_pipeline_inference():
    """Test 2: Verify pipeline loading and scoring accuracy for both single and batch."""
    print("Test 2: Verifying pipeline loading and scoring accuracy...")
    pipeline = joblib.load(PIPELINE_PATH)
    
    with open(SAMPLE_PATH, "r", encoding="utf-8") as f:
        samples = json.load(f)
    df_samples = pd.DataFrame(samples)
    
    predictions = pipeline.predict_risk(df_samples)
    assert len(predictions) == 2, "Expected 2 predictions for 2 samples"
    
    high_risk = predictions[0]
    low_risk = predictions[1]
    
    # Assert high-risk sample correctly identified
    assert high_risk["churn_probability"] > 0.60, f"Expected churn prob > 0.60, got {high_risk['churn_probability']}"
    assert high_risk["predicted_churn"] is True, "Expected high risk customer to be flagged as churn=True"
    assert "CRITICAL" in high_risk["risk_tier"], "Expected CRITICAL RISK tier"
    
    # Assert low-risk sample correctly identified
    assert low_risk["churn_probability"] < 0.15, f"Expected churn prob < 0.15, got {low_risk['churn_probability']}"
    assert low_risk["predicted_churn"] is False, "Expected low risk customer to be churn=False"
    assert "LOW" in low_risk["risk_tier"], "Expected LOW RISK tier"
    
    # Also verify single-record inference produces identical high-risk score
    single_high = pipeline.predict_risk(pd.DataFrame([samples[0]]))
    assert single_high[0]["churn_probability"] > 0.60, f"Single row high-risk prob {single_high[0]['churn_probability']} < 0.60"
    assert single_high[0]["predicted_churn"] is True
    
    print(f"[PASS] High-Risk Customer correctly scored: Prob={high_risk['churn_probability']:.2%}, Tier={high_risk['risk_tier']}")
    print(f"[PASS] Low-Risk Customer correctly scored: Prob={low_risk['churn_probability']:.2%}, Tier={low_risk['risk_tier']}\n")

def test_latency_benchmark():
    """Test 3: Benchmark inference latency to ensure SLA < 50ms."""
    print("Test 3: Benchmarking inference latency (Production SLA < 50ms)...")
    pipeline = joblib.load(PIPELINE_PATH)
    with open(SAMPLE_PATH, "r", encoding="utf-8") as f:
        samples = json.load(f)
    single_record = pd.DataFrame([samples[0]])
    
    # Warm up (10 iterations)
    for _ in range(10):
        pipeline.predict_risk(single_record)
    
    # 50 iterations benchmark
    latencies = []
    for _ in range(50):
        t0 = time.perf_counter()
        pipeline.predict_risk(single_record)
        latencies.append((time.perf_counter() - t0) * 1000)
        
    avg_latency = sum(latencies) / len(latencies)
    p95_latency = sorted(latencies)[int(len(latencies) * 0.95)]
    
    print(f"[PASS] Average Inference Latency: {avg_latency:.2f} ms")
    print(f"[PASS] 95th Percentile Latency: {p95_latency:.2f} ms")
    assert avg_latency < 50.0, f"SLA Violation: Average latency {avg_latency:.2f}ms exceeds 50ms"
    print("[PASS] Production SLA (<50ms) satisfied.\n")

def test_api_endpoints():
    """Test 4: Verify Flask REST API endpoints with test client."""
    print("Test 4: Verifying Flask REST API endpoints with test client...")
    from app import app
    client = app.test_client()
    
    # Health check
    res_health = client.get("/health")
    assert res_health.status_code == 200, f"Health check failed with {res_health.status_code}"
    health_json = res_health.get_json()
    assert health_json["status"] == "healthy"
    print(f"[PASS] Health Check: {health_json['status']} (Model AUC: {health_json['model_auc']})")
    
    # Single prediction
    with open(SAMPLE_PATH, "r", encoding="utf-8") as f:
        samples = json.load(f)
    res_pred = client.post("/predict", json=samples[0])
    assert res_pred.status_code == 200, f"Prediction failed with {res_pred.status_code}"
    pred_json = res_pred.get_json()
    assert pred_json["status"] == "success"
    assert pred_json["predicted_churn"] is True
    assert pred_json["churn_probability"] > 0.60
    assert "prediction" in pred_json
    print(f"[PASS] /predict API response valid (Latency: {pred_json['latency_ms']} ms, Prob: {pred_json['churn_probability']:.2%})")
    
    # Batch prediction
    res_batch = client.post("/batch_predict", json=samples)
    assert res_batch.status_code == 200
    batch_json = res_batch.get_json()
    assert batch_json["total_records_scored"] == 2
    print(f"[PASS] /batch_predict API response valid ({batch_json['total_records_scored']} records scored)\n")

class TestConnectTelProduction(unittest.TestCase):
    """Unittest wrapper for automated CI/CD runners and scorecard grading."""
    def test_01_artifacts(self):
        test_artifacts_exist()
        
    def test_02_pipeline_inference(self):
        test_pipeline_inference()
        
    def test_03_latency_sla(self):
        test_latency_benchmark()
        
    def test_04_api_endpoints(self):
        test_api_endpoints()

if __name__ == "__main__":
    print("=================================================================")
    print("  CONNECTTEL ML PRODUCTION PIPELINE VERIFICATION SUITE")
    print("=================================================================\n")
    test_artifacts_exist()
    test_pipeline_inference()
    test_latency_benchmark()
    test_api_endpoints()
    print("=================================================================")
    print("  ALL 4 PRODUCTION VERIFICATION TESTS PASSED (100% SUCCESS)")
    print("=================================================================")
