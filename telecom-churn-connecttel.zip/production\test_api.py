"""
ConnectTel Telecommunications - Production REST API Automated Test Suite
Implements standard Python unittest.TestCase for standalone and autograder discovery.
"""

import warnings
warnings.filterwarnings("ignore", message=".*unpickle estimator.*")
try:
    from sklearn.exceptions import InconsistentVersionWarning
    warnings.filterwarnings("ignore", category=InconsistentVersionWarning)
except ImportError:
    pass

import os
import sys
import time
import json
import socket
import threading
import urllib.request
import unittest

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROD_DIR = CURRENT_DIR if os.path.exists(os.path.join(CURRENT_DIR, "app.py")) else os.path.join(CURRENT_DIR, "production")

if PROD_DIR not in sys.path:
    sys.path.insert(0, PROD_DIR)
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

# Locate sample customers file
def find_sample_file():
    candidates = [
        os.path.join(PROD_DIR, "sample_customers.json"),
        os.path.join(CURRENT_DIR, "sample_customers.json"),
        os.path.join(CURRENT_DIR, "production", "sample_customers.json"),
        os.path.join(os.path.dirname(CURRENT_DIR), "sample_customers.json"),
        os.path.join(os.path.dirname(CURRENT_DIR), "production", "sample_customers.json")
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return os.path.join(PROD_DIR, "sample_customers.json")

SAMPLE_PATH = find_sample_file()
with open(SAMPLE_PATH, "r", encoding="utf-8") as f:
    SAMPLES = json.load(f)

from app import app

class TestConnectTelAPI(unittest.TestCase):
    """Full API test suite covering unit, integration, error handling, and socket calls."""

    @classmethod
    def setUpClass(cls):
        cls.client = app.test_client()

    def test_01_health_check_endpoint(self):
        """Verify GET /health returns 200 and correct service status."""
        res = self.client.get("/health")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "healthy")
        self.assertTrue(data.get("pipeline_loaded"))
        self.assertAlmostEqual(data.get("model_auc"), 0.8457, places=3)
        print("[PASS] Test 01: /health endpoint verified (HTTP 200)")

    def test_02_root_endpoint(self):
        """Verify GET / returns 200."""
        res = self.client.get("/")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "healthy")
        print("[PASS] Test 02: Root / endpoint verified (HTTP 200)")

    def test_03_predict_single_high_risk(self):
        """Verify POST /predict accurately scores high-risk subscriber."""
        res = self.client.post("/predict", json=SAMPLES[0])
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("churn_probability", data)
        self.assertGreater(data["churn_probability"], 0.60)
        self.assertEqual(data["churn_prediction"], 1)
        self.assertTrue(data["predicted_churn"])
        self.assertIn("CRITICAL", data["risk_tier"])
        self.assertIn("recommended_retention_action", data)
        print(f"[PASS] Test 03: High-risk scoring verified (Prob: {data['churn_probability']:.2%}, Tier: {data['risk_tier']})")

    def test_04_predict_single_low_risk(self):
        """Verify POST /predict accurately scores low-risk loyal subscriber."""
        res = self.client.post("/predict", json=SAMPLES[1])
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("churn_probability", data)
        self.assertLess(data["churn_probability"], 0.15)
        self.assertEqual(data["churn_prediction"], 0)
        self.assertFalse(data["predicted_churn"])
        self.assertIn("LOW", data["risk_tier"])
        print(f"[PASS] Test 04: Low-risk scoring verified (Prob: {data['churn_probability']:.2%}, Tier: {data['risk_tier']})")

    def test_05_predict_wrapped_payload(self):
        """Verify POST /predict accepts wrapped payloads like {'data': {...}}."""
        wrapped = {"data": SAMPLES[0]}
        res = self.client.post("/predict", json=wrapped)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertGreater(data["churn_probability"], 0.60)
        print("[PASS] Test 05: Wrapped payload format verified (HTTP 200)")

    def test_06_predict_list_payload(self):
        """Verify POST /predict accepts arrays of customer records."""
        res = self.client.post("/predict", json=SAMPLES)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertEqual(data.get("total_records_scored"), 2)
        print(f"[PASS] Test 06: List payload scoring verified ({data.get('total_records_scored')} scored)")

    def test_07_batch_predict_endpoint(self):
        """Verify POST /batch_predict scores multiple records."""
        res = self.client.post("/batch_predict", json=SAMPLES)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertEqual(data.get("total_records_scored"), 2)
        self.assertEqual(len(data.get("predictions", [])), 2)
        print(f"[PASS] Test 07: /batch_predict endpoint verified ({data.get('total_records_scored')} scored)")

    def test_08_error_handling_empty_payload(self):
        """Verify POST /predict returns 400 Bad Request on empty payload."""
        res = self.client.post("/predict", json={})
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertEqual(data.get("status"), "error")
        print("[PASS] Test 08: Error handling for empty payload verified (HTTP 400)")

    def test_09_predict_get_endpoint(self):
        """Verify GET /predict returns endpoint documentation."""
        res = self.client.get("/predict")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("endpoint"), "/predict")
        print("[PASS] Test 09: GET /predict documentation verified (HTTP 200)")

    def test_10_live_http_server_socket(self):
        """Verify live network HTTP request over real TCP socket."""
        # Find an open port
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('127.0.0.1', 0))
        live_port = sock.getsockname()[1]
        sock.close()

        # Start server in background thread (supports both werkzeug and standard library wsgiref)
        try:
            from werkzeug.serving import make_server
        except ImportError:
            from wsgiref.simple_server import make_server
        server = make_server('127.0.0.1', live_port, app)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()
        time.sleep(0.3)

        try:
            # 1. Test live GET /health
            url_health = f"http://127.0.0.1:{live_port}/health"
            with urllib.request.urlopen(url_health, timeout=5) as response:
                self.assertEqual(response.status, 200)
                data = json.loads(response.read().decode('utf-8'))
                self.assertEqual(data.get("status"), "healthy")

            # 2. Test live POST /predict
            url_predict = f"http://127.0.0.1:{live_port}/predict"
            req_data = json.dumps(SAMPLES[0]).encode('utf-8')
            req = urllib.request.Request(
                url_predict, 
                data=req_data, 
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                self.assertEqual(response.status, 200)
                pred_data = json.loads(response.read().decode('utf-8'))
                self.assertEqual(pred_data.get("status"), "success")
                self.assertGreater(pred_data.get("churn_probability"), 0.60)
                
            print(f"[PASS] Test 10: Live network socket HTTP test verified (Port {live_port}: HTTP 200)")
        finally:
            server.shutdown()

if __name__ == "__main__":
    print("=================================================================")
    print("  CONNECTTEL REST API AUTOMATED VERIFICATION SUITE")
    print("=================================================================\n")
    unittest.main(verbosity=2)
